<?php
// Show errors for development (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection for online hosting
$dbHost = 'localhost';
$dbName = 'luxdemoestate_cv'; 
$dbUser = 'luxdemoestate_CV';
$dbPass = '!]5=Y75m}+MCuSU7';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    http_response_code(500);
    die('<div class="container py-5"><div class="alert alert-danger">Database connection failed: ' 
        . htmlspecialchars($conn->connect_error) . '</div></div>');
}

// Set charset to UTF-8
$conn->set_charset("utf8mb4");

// Safe echo helper (escapes output)
function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
